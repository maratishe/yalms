#!/bin/bash
#FFMPEG installation script

#  Copyright (C) 2007-2012 Sherin.co.in. All rights reserved.
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
RED='\033[01;31m'
RESET='\033[0m'
GREEN='\033[01;32m'
_version=`cat ./version.txt`
clear
echo -e "$GREEN*************************************************************$RESET"
echo -e "          FFmpeg  Installation Wizard  Version $GREEN $_version $RESET"
echo -e "       Copyright (c) 2007-2012  http://syslint.com/"
echo -e "   Linux Server Management And Software Development Services  "
echo -e "$GREEN*************************************************************$RESET"
echo " "
echo " "
echo " "
echo " "
export who=`whoami`
lpid=$$
echo "">/var/log/ffmpeginstall.$_version.log.$lpid
echo " All operations are loged to /var/log/ffmpeginstaller.$_version.log.$lpid  . Check the logs for any failure"
echo -e "$RED"
echo "***************************************************************************************************************"
echo "  The ffmpeg-php externsion is removed from  version 6.1. This is no longer supported. If you need to install "
echo "  this package  please  request an installation service from http://www.ffmpeginstaller.com/"
echo "***************************************************************************************************************"
echo -e "$RESET"
echo -n "If you need to cancell  the installation press Ctrl+C  if not installation will start within 10 seconds..........."
sleep 10
if [[ $who == "root" ]];then
       sh start.sh | tee /var/log/ffmpeginstaller.$_version.log.$lpid
else
        echo "                  Sorry  Buddy, you are not a root user. This is not for yours."
        echo "                  If you wish to install ffmpeg as  $who please use sharedhostffmpeg.x.x.x"
        echo "                  You will get it from the project home page http://www.ffmpeginstaller.com/"
fi

